# Shopify Admin API (WSO2)

Este componente empaqueta la API `ShopifyAdminAPI-1.0.0` lista para importarse en la pasarela de APIs de WSO2 y exponer operaciones reales de Shopify sin uso de mocks.

## 📋 Prerrequisitos

- **WSO2 API Manager** (4.1 o superior) o **WSO2 Micro Integrator** según el flujo de despliegue definido por tu organización.
- Acceso válido a la tienda de Shopify que actuará como backend (con token OAuth y permisos suficientes).
- **Git** y **curl** instalados para clonar y probar.
- Opcional: **WSO2 CLI (`apictl`)** para automatizar la importación y promoción.

## 📂 Estructura del Proyecto

```
ShopifyAdminAPI-1.0.0/
├─ Definitions/
│  └─ swagger.yaml        # Definición OpenAPI con todas las reglas de scoring aplicadas
├─ Docs/
│  └─ README.md           # Resumen de documentación operativa
├─ Sequences/             # (Si aplica) mediaciones personalizadas
└─ README.md              # Este archivo
```

## 🚀 Despliegue

### 1. Clonar el paquete

```bash
git clone <REPOSITORIO>
cd ShopifyAdminAPI-1.0.0
```

### 2. Importar en WSO2 API Manager

**Opción A – Publisher UI**
1. Inicia sesión en el Publisher.
2. Selecciona **Import API** → **Import OpenAPI Archive**.
3. Sube el ZIP o carpeta `ShopifyAdminAPI-1.0.0`.
4. Revisa que los endpoints y políticas de seguridad queden configurados.

**Opción B – CLI (`apictl`)**

```bash
apictl login dev -u <usuario> -p <password> --apim https://localhost:9443
apictl import api -f ./ -e dev
```

## 🔧 Configuración

- **Endpoints**: en el Publisher ajusta los `Production/Sandbox Endpoints` a la versión de la API de Shopify que utilices (ej. `https://<tienda>.myshopify.com/admin/api/2024-07`).
- **Seguridad**:
  - Conservar los tres esquemas declarados en `swagger.yaml`: `oauth2`, `bearerAuth` y `basicAuth`, tal como requiere la política de gobierno.
  - Configura los **application scopes** en `APIM` para que coincidan con los definidos (`read:products`).
- **Headers**: asegúrate de propagar `X-Shopify-Access-Token` desde el gateway si Shopify lo exige.
- **CORS**: está deshabilitado por defecto (`corsConfigurationEnabled: false`). Actívalo en Publisher si el consumo será desde navegadores.

## 🖥️ Requerimientos de Ejecución

- Gateway/APIM activo (no se permiten mocks según las políticas del proyecto).
- Conectividad HTTPS hacia Shopify. Usa certificados confiables o importa certificados intermedios en el truststore de WSO2.
- Scripts de arranque: si utilizas automatizaciones locales, sigue la convención corporativa e invoca el `*.sh` provisto (por ejemplo `./start-apim.sh`).

## 🎯 Uso de la API

### Autenticación
- Genera un **Application Token** en el Developer Portal y solicita los scopes necesarios.
- Alternativamente, configura **Basic Auth** o **Bearer** según el consumidor.

### Endpoints principales

| Operación | Método | Path | Resumen |
|-----------|--------|------|---------|
| `getProductById` | GET | `/shopify/1.0.0/products/{productId}.json` | Obtiene un producto |
| `updateProductById` | PUT | `/shopify/1.0.0/products/{productId}.json` | Actualiza un producto |
| `listProducts` | GET | `/shopify/1.0.0/products.json` | Lista productos |
| `getProductsCount` | GET | `/shopify/1.0.0/products/count.json` | Devuelve el conteo |

### Ejemplos con curl

```bash
# Obtener producto
curl -k https://<GW_HOST>/shopify/1.0.0/products/1234567890.json \
  -H "Authorization: Bearer <TOKEN>"

# Actualizar producto (requiere body válido)
curl -k -X PUT https://<GW_HOST>/shopify/1.0.0/products/1234567890.json \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  --data '{"product": {"title": "Nuevo título desde gateway"}}'
```

## 🛠️ Mantenimiento y Desarrollo

- **Modificaciones al OpenAPI**: edita `Definitions/swagger.yaml` respetando las reglas de scoring (contacto, summaries, ejemplos, responses, etc.). Siempre vuelve a ejecutar el validador interno.
- **Versionado**: si la API evoluciona, incrementa `info.version` y actualiza el `x-wso2-basePath`.
- **Testing**: valida primero contra el servicio local de Shopify o entorno sandbox, y luego contra el APIM productivo siguiendo la guía de integración de tu organización.
- **Sin datos hardcodeados**: cualquier credencial o identificador debe provenir de parámetros o secretos gestionados fuera del repositorio.

## 🔍 Troubleshooting

- **401/403**: verifica scopes y credenciales configuradas en la aplicación consumidora.
- **5xx**: consulta los logs de APIM y la respuesta de Shopify; revisa cuotas de la tienda.
- **Timeouts (504)**: asegúrate de que la URL de Shopify sea alcanzable y considera aumentar los timeouts en la política de endpoint.
- **Validación fallida**: ejecuta el verificador de diseño proporcionando el `swagger.yaml`; corrige advertencias antes de promover a otros entornos.

## 📊 Comandos Útiles

```bash
# Probar disponibilidad del gateway
curl -k https://<GW_HOST>/services/Version

# Inspeccionar logs de WSO2 (Linux/Mac)
tail -f <APIM_HOME>/repository/logs/wso2carbon.log

# Verificar certificados instalados en truststore
keytool -list -keystore <APIM_HOME>/repository/resources/security/client-truststore.jks
```

## 📞 Soporte

- Equipo Shopify Admin: `api-support@tu-dominio.com`
- Reporta incidencias siguiendo el flujo de tickets interno (adjunta logs y request ID del gateway).

---

Mantén este README actualizado cada vez que cambie la configuración, la versión de la API o los procedimientos operativos.

