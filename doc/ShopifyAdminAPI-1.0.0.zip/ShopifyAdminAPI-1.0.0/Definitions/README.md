# About

Este directorio contiene la definición OpenAPI `swagger.yaml` de `ShopifyAdminAPI-1.0.0`.
Documenta los endpoints reales expuestos por el gateway de WSO2 para gestionar productos de Shopify.
Debe mantenerse sincronizado con la configuración publicada en APIM y seguir las reglas de scoring.
Cualquier cambio en los endpoints o modelos debe actualizarse aquí antes de ejecutar la validación.
Para información operativa adicional, consulta el README principal y la guía en `Docs/README.md`.
