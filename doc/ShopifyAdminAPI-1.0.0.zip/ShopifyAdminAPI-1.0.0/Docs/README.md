# Documentación ShopifyAdminAPI

Este directorio contiene materiales de soporte para la API `ShopifyAdminAPI-1.0.0`. Utiliza esta guía como referencia rápida al importar el paquete en WSO2.

## Contenido

- `swagger.yaml`: la definición OpenAPI con resúmenes, ejemplos y respuestas completas.
- `README.md` (raíz del paquete): instrucciones detalladas de despliegue, configuración y troubleshooting.
- Logs o capturas de pruebas (añadir aquí según sea necesario).

## Pasos para desplegar

1. Importa el paquete en el Publisher de WSO2 (o usa `apictl import api -f ./`).
2. Ajusta los endpoints de producción/sandbox a tu tienda Shopify.
3. Publica la API y suscribe una aplicación con scopes `read:products`.

## Notas de mantenimiento

- No utilices mocks; esta API debe apuntar a los endpoints reales de Shopify.
- Mantén sincronizada la versión (`info.version`) con el `x-wso2-basePath`.
- Ejecuta el validador de diseño antes de promover la API a otros entornos.

Para información ampliada consulta el README principal en la raíz del paquete.

